public class NYPepperoniPizza extends Pizza{
    public NYPepperoniPizza(){
        name="NY style Pepperoni";
        dough="Thin crust dough";
        sauce="Mariana sauce";
        toppings.add("Italian Pepperoni cheese");
    }
}
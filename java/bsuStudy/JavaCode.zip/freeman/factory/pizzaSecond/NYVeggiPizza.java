public class NYVeggiPizza extends Pizza{
    public NYVeggiPizza(){
        name="NY style veggi";
        dough="Thin crust dough";
        sauce="Mariana sauce";
        toppings.add("potato");
    }
}
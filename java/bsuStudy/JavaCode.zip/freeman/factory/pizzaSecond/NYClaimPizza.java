public class NYClaimPizza extends Pizza{
    public NYClaimPizza(){
        name="NY style claim";
        dough="Thin crust dough";
        sauce="Mariana sauce";
        toppings.add("Italian cheese");
    }
}
public class NYCheesePizza extends Pizza{
    public NYCheesePizza(){
        name="NY style Sauce and cheese pizza";
        dough="Thin crust dough";
        sauce="Mariana sauce";
        toppings.add("Reggiano cheese");
    }
}
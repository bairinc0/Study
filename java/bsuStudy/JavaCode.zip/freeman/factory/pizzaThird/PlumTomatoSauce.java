public class PlumTomatoSauce implements Sauce{
	public String toString(){
		return "PlumTomatoSauce";
	}
}
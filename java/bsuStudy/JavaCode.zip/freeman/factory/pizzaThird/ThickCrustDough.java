public class ThickCrustDough implements Dough{
	public String toString(){
		return "ThickCrustDough";
	}
}
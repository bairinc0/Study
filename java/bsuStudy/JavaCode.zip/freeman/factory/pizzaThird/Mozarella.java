public class Mozarella implements Cheese{
	public String toString(){
		return "Mozarella cheese";
	}
}
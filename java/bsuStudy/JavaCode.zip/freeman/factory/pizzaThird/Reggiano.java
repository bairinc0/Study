public class Reggiano implements Cheese{
	public String toString(){
		return "Reggiano cheese";
	}
}
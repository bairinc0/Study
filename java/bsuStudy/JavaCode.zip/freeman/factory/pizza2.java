Pizza orderPizza(String type){
	SimplePizzaFactory factory=new SimplePizzaFactory();
	Pizza pizza=factory.createPizza(type);
	pizza.prepare();
	pizza.bake();
	pizza.cut();
	pizza.box();
	return pizza;
}
void showPizzaOnScreen(String type){
	SimplePizzaFactory factory=new SimplePizzaFactory();
	Pizza pizza=factory.createPizza(type);
	Display displayTablet=new DisplayTablet();
	displayTablet.showPizza(pizza);
}
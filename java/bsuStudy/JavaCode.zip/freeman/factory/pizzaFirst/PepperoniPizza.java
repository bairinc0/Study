public class PepperoniPizza extends Pizza{
    void prepare(){
        System.out.println("Prepare PepperoniPizza");
    }
    void bake(){
         System.out.println("bake PepperoniPizza");
    }
    void cut(){
         System.out.println("cut PepperoniPizza");
    }
    void box(){
         System.out.println("box PepperoniPizza");
    }
}
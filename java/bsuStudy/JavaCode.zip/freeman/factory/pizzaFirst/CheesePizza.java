public class CheesePizza extends Pizza{
    void prepare(){
        System.out.println("Prepare CheesePizza");
    }
    void bake(){
         System.out.println("bake CheesePizza");
    }
    void cut(){
         System.out.println("cut CheesePizza");
    }
    void box(){
         System.out.println("box CheesePizza");
    }
}
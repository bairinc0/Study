public class ClaimPizza extends Pizza{
    void prepare(){
        System.out.println("Prepare claimPizza");
    }
    void bake(){
         System.out.println("bake claimPizza");
    }
    void cut(){
         System.out.println("cut claimPizza");
    }
    void box(){
         System.out.println("box claimPizza");
    }
}
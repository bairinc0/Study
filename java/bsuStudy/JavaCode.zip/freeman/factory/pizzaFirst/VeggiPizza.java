public class VeggiPizza extends Pizza{
    void prepare(){
        System.out.println("Prepare VeggiPizza");
    }
    void bake(){
         System.out.println("bake VeggiPizza");
    }
    void cut(){
         System.out.println("cut VeggiPizza");
    }
    void box(){
         System.out.println("box VeggiPizza");
    }
}
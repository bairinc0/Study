interface PizzaFactory {
    public Pizza createPizza(String type);
}
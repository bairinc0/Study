public class PizzaStore{
	SimplePizzaFactory factory;
	public PizzaStore(){
		factory=new SimplePizzaFactory();
	}
	Pizza orderPizza(String type){		
		Pizza pizza=factory.createPizza(type);
		pizza.prepare();
		pizza.bake();
		pizza.cut();
		pizza.box();
		return pizza;
	}
	void showPizzaOnScreen(String type){
		Pizza pizza=factory.createPizza(type);
		Display displayTablet=new DisplayTablet();
		displayTablet.showPizza(pizza);
	}
}
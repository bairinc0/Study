public class DependPizzaStore{
	public Pizza orderPizza(String name,String city){
		Pizza pizza=null;
		if (city.equals("NY")){
			if (name.equals("cheese")){
				pizza=new NYCheesePizza();
			}
			else if (name.equals("veggi")){
				pizza=new NYVeggiPizza();
			}
		}
		else if (style.equals("Chicago")){
			if (name.equals("cheese")){
				pizza=new ChicagoCheesePizza();
			}
			else if (name.equals("veggi")){
				pizza=new ChicagoVeggiPizza();
			}
		}
		pizza.prepare();
		pizza.bake();
		pizza.cut();
		pizza.box();
		return pizza;
	}
}
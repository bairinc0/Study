public interface Quackable{
    public void quack();
}
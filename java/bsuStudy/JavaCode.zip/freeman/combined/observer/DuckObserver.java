public interface DuckObserver{
    public void update(QuackObservable duck);
}
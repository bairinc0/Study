package freeman.observer.weatherData.weather;

public interface DisplayElement{
    public void display();
}
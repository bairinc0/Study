public class Coffee extends CaffeineBeverage{
    void brew(){
        System.out.println("Add Coffee");
    }
    void addCondiments(){
        System.out.println("Add milk and sugar");
    }
    
}
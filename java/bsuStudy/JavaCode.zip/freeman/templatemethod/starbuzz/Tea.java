public class Tea extends CaffeineBeverage{
    void brew(){
        System.out.println("Add tea");
    }
    void addCondiments(){
        System.out.println("Add lemon");
    }
    
}
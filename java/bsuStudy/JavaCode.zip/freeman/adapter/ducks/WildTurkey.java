public class WildTurkey implements Turkey{
    public void gobble(){
        System.out.println("Gobble!");
    }
    public void fly(){
        System.out.println("I can fly on short distances");
    }
}
interface FlyBehavior{
    public void fly();
}
interface QuackBehavior{
    public void quack();
}
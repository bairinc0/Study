class SwordBehavior implements WeaponBehavior{
    public void useWeapon(){
        System.out.println("Using Sword!");
    }
}
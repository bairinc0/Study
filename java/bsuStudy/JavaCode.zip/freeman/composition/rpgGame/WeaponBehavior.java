interface WeaponBehavior{
    public void useWeapon();
}
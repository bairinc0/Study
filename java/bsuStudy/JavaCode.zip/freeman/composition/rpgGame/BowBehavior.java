class BowBehavior implements WeaponBehavior{
    public void useWeapon(){
        System.out.println("Using Bow!");
    }
}
class HeadLaser implements WeaponBehavior{
    public void useWeapon(){
        System.out.println("Using Head Laser!");
    }
}
class NoWeaponBehavior implements WeaponBehavior{
    public void useWeapon(){
        System.out.println("Free hands!");
    }
}
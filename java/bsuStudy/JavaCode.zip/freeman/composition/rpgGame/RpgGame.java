import java.util.*;
public class RpgGame{
    public static void main(String [] args){
        /*Hero knight=new Knight("Arthur");
		knight.fight();
		knight.setWeapon(new BowBehaviour());
		*/
		/*ArrayList<Hero> arr=new ArrayList<Hero>();
        arr.add(new Archer("Sylvanas"));
        arr.add(new Knight("Uther"));
		
        arr.add(new Berserk("Grom Hellscream"));
        for (Hero c:arr){
            c.fight();
            c.battleCry();
        }*/
		Hero shark =new Shark();
		shark.fight();
		shark.setWeapon(new HeadLaser());
    }
}
abstract class Beverage{
	private double milkCost;
	private double soyCost;
	private double mochaCost;
	private double whipCost;
	private int milk;
	private int soy;
	private int mocha;
	private int whip;
	protected String description;
	public class Beverage(){
		milkCost=0.99;
		soyCost=0.15;
		mochaCost=1.2;
		whipCost=1.5;
	}
	protected boolean hasMilk(){
		if (milk==1){
			return true;
		}
		else{
			return false;
		}
	}
	protected void setMilk(){
		milk=1;
	}
	/*Методы для soy, mocha,whip*/
	public double cost(){
		double condinmentCost=0.0;
		if (hasMilk()){
			condinmentCost+=milkCost;
		}
		if (hasSoy()){
			condinmentCost+=soyCost;
		}
		if (hasMocha()){
			condinmentCost+=mochaCost;
		}
		if (hasWhip()){
			condinmentCost+=whipCost;
		}
		return condinmentCost;
	}
}
public class DarkRoast extends Beverage{
	private double darkRoastCost;
	public DarkRoast(){
		description="Most excellent Dark Roast";
		darkRoastCost=1.99;
	}
	public double cost(){
		return darkRoastCost+super.cost();
	}
}
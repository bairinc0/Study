public class DarkRoast extends Beverage{
    public DarkRoast(){
        description="Dark Roast";
    }
    public double cost(){
        double standard=0.79;  
		if (getSize()==2){
			standard=standard*1.2;
		}
		else if(getSize()==3){
			standard=standard*1.5;
		}
        return standard;
    }
    
}
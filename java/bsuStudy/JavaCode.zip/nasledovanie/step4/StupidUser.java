public class StupidUser{
	public static void main(String [] s){
		Calculator c=new Calculator();
		//очень тупой код
		//Calc1 c=new Calc1();
		c.setNum1(100);
		System.out.println(c.getNum1());
		System.out.println(c.calc());
	}
}
class Calc1 extends Calculator{
	public Calc1(){
		//очень тупой код
		number1=23;
	}
}
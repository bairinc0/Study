public class Calculator{
	protected double number1;
	private double number2;
	private double discount=90;
	public Calculator(){
		//Секретный программный код
		number1=20;
		number2=15;
	}
	public void setNum1(double number1){
		if (number1>=0){
			this.number1=number1;
		}
		else{
			System.out.println("ERROR!!!!");
			this.number1=0;
		}
	}
	public double getNum1(){
		return number1*(discount/100);
	}
	public double calc(){
		return number1/number2;
	}
}
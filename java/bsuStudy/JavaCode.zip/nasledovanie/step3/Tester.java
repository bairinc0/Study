public class Tester{
	public static void main(String [] s){
		Fish f=new Fish();
		f.name="Blue Fish";
		f.say();
		f.say(4);		
	}
}
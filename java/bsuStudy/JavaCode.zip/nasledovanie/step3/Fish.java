public class Fish extends Animal{
	public void say(int i){
		System.out.println("I am fish, and i have "+i+" friends");
	}
}
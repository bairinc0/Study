public class Animal{
	public int weight;
	public String name;
	
	public void say(){
		System.out.println("I am animal, and my name is "+name);
	}
}

public class Bird extends Animal{
	public void say(){
		System.out.println("I am bird!!!");
	}
}
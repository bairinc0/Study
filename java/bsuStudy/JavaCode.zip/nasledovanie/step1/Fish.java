public class Fish extends Animal{
	public void say(){
		System.out.println("I am fish, and my name is "+name);
	}
}
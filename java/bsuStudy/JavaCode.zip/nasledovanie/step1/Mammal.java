public class Mammal extends Animal{
	public void say(){
		System.out.println("I am mammal");
	}
}
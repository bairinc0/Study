public class Animal{
	public double weight;
	public String name;
	public Animal(){
		System.out.println("Animal created");
	}
	public void say(){
		System.out.println("I am animal, and my name is "+name);
	}
}

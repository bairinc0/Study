public class Bird extends Animal{
	public Bird(){
		System.out.println("Bird created");
	}
	public void say(){
		System.out.println("I am bird!!!");
	}
}
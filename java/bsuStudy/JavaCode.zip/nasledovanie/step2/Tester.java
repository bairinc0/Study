public class Tester{
	public static void main(String [] s){
		Swan f=new Swan();		
		for (int i=0;i<15;i++)
			System.out.print("==");
		System.out.println("");
		Cow c=new Cow(20.5);
		//System.out.println("cow weigth="+c.weight);
	}
}
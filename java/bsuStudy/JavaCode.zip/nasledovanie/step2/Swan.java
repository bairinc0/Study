public class Swan extends Bird{
	public Swan(){
		System.out.println("Swan created!");
	}
}
public class Fish extends Animal{
	public Fish(){
		System.out.println("Fish created");
	}
}
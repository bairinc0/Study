public class Mammal extends Animal{
	public Mammal(double weight){
		this.weight=weight;		
		System.out.println("Fat Mammal created!!");
	}
	public Mammal(){
		System.out.println("Mammal created!!");
	}
	public void say(){
		System.out.println("I am mammal");
	}
}
public class Cow extends Mammal{
	public Cow(){		
		System.out.println("Cow created");
	}
	public Cow(double weight){
		super(weight);
		System.out.println("Cow created, and weight="+weight);
	}
}
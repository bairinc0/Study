public class Animal{
	protected double weigth;
	protected double price;
	protected String type;
	public double meatPrice(){
		return weigth*price;
	}
	public void setWeigth(double weigth){
		if (weigth>=0){
			this.weigth=weigth;
		}
		else{
			System.out.println("Bad value for weigth were transferred");
			this.weigth=0;
		}
	}
	public double getWeigth(){
		return weigth*0.9;//Заботимся о прользователях
	}
	public void setPrice(double price){
		if (price>=0){
			this.price=price;
		}
		else{
			System.out.println("Bad value for price were transferred");
			this.price=0;
		}
	}
	public double getPrice(){
		return price;
	}
	public void setType(String type){
		this.type=type;
	}
	public String getType(){
		return type;
	}
	public Animal(){
		setWeigth(0);
		setPrice(0);
		setType("Unknown type");
	}
	public Animal(double weigth,double price,String type){
		setWeigth(weigth);
		setPrice(price);
		setType(type);
	}
	public void info(){
		System.out.println("Animal type:"+getType());
		System.out.println("Animal weigth:"+getWeigth());
		System.out.println("Animal price:"+getPrice());
	}
}
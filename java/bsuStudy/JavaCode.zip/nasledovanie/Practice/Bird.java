public class Bird extends Animal{
	private int eggPerWeek;
	private double eggsPrice;//стоимость за десяток
	public int getEggsCount(){
		return eggPerWeek;
	}
	public void setEggsCount(int eggPerWeek){
		if (eggPerWeek>=0){
			this.eggPerWeek=eggPerWeek;
		}
		else{
			System.out.println("Wrong eggs value transferred");
			this.eggPerWeek=0;
		}
	}
	public double getEggsPrice(){
		return eggsPrice;
	}
	public void setEggsPrice(double eggsPrice){
		if (eggsPrice>=0){
			this.eggsPrice=eggsPrice;
		}
		else{
			System.out.println("Wrong eggs price value transferred");
			this.eggsPrice=0;
		}
	}
	public Bird(){
		setEggsPrice(0);
		setEggsCount(0);
	}
	public Bird(int eggPerWeek,double eggsPrice,double weigth,double price,String type){
		super(weigth,price,type);
		setEggsPrice(eggsPrice);
		setEggsCount(eggPerWeek);
	}
	public double yearProfit(){
		return getEggsCount()*getEggsPrice()/10+meatPrice();
	}
	/*public void info(){
		//info();
		System.out.println("sss");
	}*/
}
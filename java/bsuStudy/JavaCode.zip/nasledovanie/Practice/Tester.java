public class Tester{
	public static void main(String [] s){
		Animal b=new Bird(5,40.6,1,60,"Holland redhead");
		//System.out.println("year profit="+b.yearProfit());
		b.info();
	}
}
public class Hello4{
	public static void main(String [] args){
		String lang="ch";
		Greet g=new Greet(lang);
		g.greeter("Vic");		
	}
}
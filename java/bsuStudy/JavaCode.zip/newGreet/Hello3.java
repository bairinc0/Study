public class Hello3{
	public static void main(String [] args){
		if (args.length>0){
			Greet g=new Greet(args[0]);							
			for (int i=1;i<args.length;i++){
				g.greeter(args[i]);
			}			
			System.out.println("count="+Greet.count);
		}	
		else{
			System.out.println("Error! Array is null!");
		}	
	}
}
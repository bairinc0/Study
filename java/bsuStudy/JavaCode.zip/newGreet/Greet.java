public class Greet{
	private String format;
	public static int count;
	public Greet(String format){
		if (format.equals("de")){
			this.format="Guten tag";
		}
		else if (format.equals("fr")){			
			this.format="Bonjuire";			
		}
		else if (format.equals("ch")){
			this.format="Ni Hao";
		}
		else{				
			this.format="Hello";	
		}				
	}
	public void greeter(String name){
		System.out.println(format+" "+name);
		count++;
	}
}
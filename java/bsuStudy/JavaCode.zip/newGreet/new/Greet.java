public class Greet{
	private String format;
	public static int count=0;
	public Greet(String format){
		change(format);
	}
	public void change(String lang){
		if (lang.equals("de")){
			format="Guten tag";
		}
		else if (lang.equals("fr")){			
			format="Bonjuire";			
		}
		else if (lang.equals("ch")){
			format="Ni Hao";
		}
		else if (lang.equals("ru")){
			format="Привет";
		}		
		else{				
			format="Hello";	
		}	
	}
	public void greeter(String name){
		System.out.println(format+" "+name);
		count++;
	}
}
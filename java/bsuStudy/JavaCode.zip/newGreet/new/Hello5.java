public class Hello5{
	public static void main(String [] args){
		Greet g=new Greet("ch");
		g.greeter("Vic");
		g.change("en");
		g.greeter("Tony");
	}
}
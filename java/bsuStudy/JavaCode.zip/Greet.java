public class Greet{
	private String format;
	public static int count=0;
	public Greet(String format){
		this.format=format;		
	}
	public void greeter(String name){
		System.out.println(format+" "+name);
		count++;
	}
}
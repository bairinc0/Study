public class Hello3{
	public static void main(String [] args){
		if (args.length>0){
			for (int j=0;j<2;j++){
				Greet g;
				if (args[0].equals("de")){
					g=new Greet("Guten tag");
				}
				else if (args[0].equals("fr")){			
					g=new Greet("Bonjuire");	
				}
				else if (args[0].equals("ch")){
					g=new Greet("Ni hao");	
				}
				else{				
					g=new Greet("Hello");
				}				
				for (int i=1;i<args.length;i++){
					g.greeter(args[i]);
				}								
			}
			System.out.println("count="+Greet.count);
		}	
		else{
			System.out.println("Error! Array is null!");
		}	
	}
}
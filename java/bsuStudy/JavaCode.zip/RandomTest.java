import java.util.*;
public class RandomTest{
	public static void main(String [] args){
		Random rand=new Random(20);
		int k=rand.nextInt(20);
		System.out.println("k="+k);
		switch (k){
			case 1:
				System.out.println("One");
				break;
			case 2:	
				System.out.println("Two");
				break;
			case 3:
				System.out.println("Three");
				break;			
			default: 	
				System.out.println("Another value");
		}
	}
}
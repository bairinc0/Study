public class DefaultConstructor{
	public 
}
class Bird{
}
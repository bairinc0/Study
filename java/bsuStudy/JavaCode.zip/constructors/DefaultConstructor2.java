public class DefaultConstructor2{
	public static void main(String [] s){
		Bird b;
		b=new Bird();
	}
}
class Bird{
	public double weight;
	public int age;
	public String color;
	public Bird(double weight){
		this.weight=weight;
	}
	public Bird(int age){
		this.age=age;
	}
}
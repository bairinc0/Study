public class DefaultConstructor3{
	public static void main(String [] s){
		Bird b;
		b=new Bird(25.5,"Green",12);
		b.info();
	}
}
class Bird{
	public double weight;
	public int age=1;
	public String color;
	public Bird(double weight){
		this.weight=weight;
	}	
	public Bird(String color){
		this.color=color;
	}
	public Bird(double weight,String color){
		this(weight);//this.weight=weight;
		this.color=color;
	}
	public Bird(double weight,String color,int age){
		//this(weight,color);
		this.weight=weight+10;
		this.color=color;
		this.age=age;
	}
	public Bird(){
		//this(2.0,"Red");
		System.out.println("Zero arguments!!!");
	}
	public void info(){
		System.out.print("Color="+color);
		System.out.print(";Weight="+weight);
		System.out.println(";Age="+age);
	}
}
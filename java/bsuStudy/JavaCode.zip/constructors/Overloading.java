class Tree{
	private int height;
	public Tree(){
		System.out.println("Seed is planted!!!");
	}
	public Tree(int initialHeight){
		height=initialHeight;
		System.out.println("Tree height="+height);
	}
	public void info(){
		if (height==0){
			System.out.println("Object is Seed");
		}
		else{
			System.out.println("Object is Tree");
		}		
	}
	public void info(String s){
		System.out.println(s);
	}
}
public class Overloading{
	public static void main(String [] a){
		Tree seed=new Tree();
		Tree tree=new Tree(10);
		seed.info();
		tree.info();
		tree.info("Hello world");
	}
}
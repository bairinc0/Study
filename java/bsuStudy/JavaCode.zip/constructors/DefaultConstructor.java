public class DefaultConstructor{
	public static void main(String [] s){
		Bird b;
		b=new Bird();
		System.out.println("Bird weight="+b.weight);
		System.out.println("Bird age="+b.age);
		System.out.println("Bird color="+b.color);
		b.color="Red";
		System.out.println("Bird color changed!!!="+b.color);
	}
}
class Bird{
	public double weight;
	public int age;
	public String color;
}
public class Constructor1{
	public static void main(String [] args){
		for (int i=0;i<3;i++){
			new MyCode(i+1);
		}
	}
}
class MyCode{
	public MyCode(int i){
		System.out.println("MyCode object number "+i+" is created");
	}
}
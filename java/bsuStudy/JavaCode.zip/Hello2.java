public class Hello2{
	public static void main(String [] args){
		if (args.length>0){
			
			/*for (int i=0;i<args.length;i++){
				System.out.println(args[i]);
			}
			*/
			for(String a:args){
				System.out.println(a);
			}	
			
		}	
		else{
			System.out.println("Error! Array is null!");
		}	
	}
}
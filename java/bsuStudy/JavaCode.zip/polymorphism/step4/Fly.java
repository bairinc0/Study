interface Fly{
	public int canFly();
}
public class Music{
	public void playMusic(Instrument instr){
		for(int i=1;i<8;i++){
			instr.play(i);
		}
	}
	public static void main(String [] args){
		Music m=new Music();
		Bird b=new Bird();
		m.playMusic(b);
	}
}
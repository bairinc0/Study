class Bird implements Instrument, Fly{
	public void play(int n){
		System.out.println("Sing bird");
	}
	public void what(){
		System.out.println("I am bird");
	}
	public int canFly(){
		return 1;
	}
}
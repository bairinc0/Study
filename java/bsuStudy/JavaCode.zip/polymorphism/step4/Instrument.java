interface Instrument{
	int VALUE=5;
	public void play(int n);
	public void what();
}

class Wind extends Instrument{
	public void play(int n){
		System.out.println("Wind plays note "+n);
	}
}
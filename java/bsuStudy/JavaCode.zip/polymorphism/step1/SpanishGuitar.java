class SpanishGuitar extends Guitar{
	public void play(int n){
		System.out.println("Spanish Guitar plays note "+n);
	}
}
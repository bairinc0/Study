class Instrument{
	public void play(int n){
		System.out.println("Instrument plays");
	}
}
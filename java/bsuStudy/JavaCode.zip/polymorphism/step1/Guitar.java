class Guitar extends Instrument{
	public void play(int n){
		System.out.println("Guitar plays note "+n);
	}
}
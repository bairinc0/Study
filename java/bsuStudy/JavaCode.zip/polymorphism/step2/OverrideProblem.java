public class OverrideProblem{
	private void f(){
		System.out.println("I am private method!!!");
	}
	public static void main(String [] args){
		OverrideProblem po=new Derived();
		po.f();
		Derived po1=new Derived();
		po1.f();
	}
}

class Derived extends OverrideProblem{
	public void f(){
		System.out.println("I am public method!!!");
	}
}
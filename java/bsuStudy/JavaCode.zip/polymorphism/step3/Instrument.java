abstract class Instrument{
	private String name="Instrument";
	public void setName(String name){
		this.name=name;
	}
	public abstract void play(int n);
	public void what(){
		System.out.println(name);
	}
}